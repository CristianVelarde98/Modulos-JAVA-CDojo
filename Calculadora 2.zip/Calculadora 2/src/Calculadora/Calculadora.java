package Calculadora;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Calculadora {
    private List<Double> numeros;
    private List<Character> operaciones;
    private boolean enProgreso;
    private double resultado;
    private static Scanner escaner = new Scanner(System.in);

    public Calculadora() {
        this.numeros = new ArrayList<>();
        this.operaciones = new ArrayList<>();
        this.resultado = 0.0;
        this.enProgreso = true;
    }

    public void nuevaOperacion(){
        System.out.println("Empezamos!!");
        System.out.println("Ingrese los numeros y operaciones que desea realizar (+), (-), (*), (/)");
        System.out.println("Cuando desee calcular el resultado ingrese el '='");
        System.out.println("Ingrese un numero: ");
        numeros.add(Double.parseDouble(escaner.nextLine()));

        do {
            System.out.println("Ingrese una operacion: ");
            char operacion = escaner.nextLine().charAt(0);

            if(validarOperacion(operacion)){
                operaciones.add(operacion);
            } else if (operacion == '=') {
                enProgreso = false;
            } else {
                System.out.println("Operación no válida");
            }

            if (validarOperacion(operacion)) {
                System.out.println("Ingrese un numero: ");
                numeros.add(Double.parseDouble(escaner.nextLine()));
            }
        } while (enProgreso);

        calcularResultado();

        System.out.println("El resultado de la operacion es: " + resultado);

        numeros.clear();
        operaciones.clear();
        resultado = 0.0;
        enProgreso = true;
    }

    private boolean validarOperacion(char operacion){
        return (operacion == '-' || operacion == '+' ||operacion == '*' ||operacion == '/');
    }

    private void calcularResultado(){
        resultado = numeros.get(0);

        for(int i = 0; i < operaciones.size(); i++){
            char operacion = operaciones.get(i);
            double numero = numeros.get(i + 1);

            switch (operacion){
                case '+':
                    resultado += numero;
                    break;
                case '-':
                    resultado -= numero;
                    break;
                case '*' :
                    resultado *= numero;
                    break;
                case '/':
                    resultado /= numero;
                    break;
            }
        }
    }
}
